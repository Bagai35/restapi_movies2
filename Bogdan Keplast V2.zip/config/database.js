// const { Sequelize } = require('sequelize');

// const sequelize = new Sequelize('books', 'root', '', {
//   host: 'localhost',
//   dialect: 'mysql',
// });

// module.exports = sequelize;


const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('books', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
});

// Создать базу данных, если она не существует
sequelize.sync({ force: true }).then(() => {
  console.log('Database created (if not exists)');
}).catch((error) => {
  console.error('Error creating database:', error);
});

module.exports = sequelize;