// const Sequelize = require('sequelize');
// const fs = require('fs');
// const path = require('path');
// const sequelize = require('./config/database'); 
// const { Book, Author, Category } = require('./models/index'); 

// // sync моделей с бд
// sequelize.sync({ force: true }).then(async () => {
//   const data = JSON.parse(fs.readFileSync('amazon.books.json', 'utf-8'));
//   // Заполните бд из джсон
  
  
//   for (const bookData of data) {
//     const book = await Book.create({
//       title: bookData.title,
//       isbn: bookData.isbn,
//       pageCount: bookData.pageCount,
//       publishedDate: new Date(bookData.publishedDate?.$date),
//       thumbnailUrl: bookData.thumbnailUrl,
//       shortDescription: bookData.shortDescription,
//       longDescription: bookData.longDescription,
//       status: bookData.status,
//     });

//     for (const authorName of bookData.authors) {
//       const [author] = await Author.findOrCreate({
//         where: { name: authorName },
//       });
//       await book.addAuthor(author);
//     }

//     for (const categoryName of bookData.categories) {
//       const [category] = await Category.findOrCreate({
//         where: { name: categoryName },
//       });
//       await book.addCategory(category);
//     }
//     { 
//       createdAt: false
//       updatedAt: false
//     }
//   }

//   console.log('Work will be done');
// });


const Sequelize = require('sequelize');
const fs = require('fs');
const path = require('path');
const ProgressBar = require('progress'); // Импортируйте библиотеку progress
const sequelize = require('./config/database'); 
const { Book, Author, Category } = require('./models/index'); 

// Откройте файл для записи SQL-запросов
const sqlLogFile = fs.createWriteStream('sql-queries.log');

// Перенаправьте вывод SQL-запросов в файл
sequelize.options.logging = (query) => {
  sqlLogFile.write(query + '\n');
};

// Получите данные из JSON файла
const data = JSON.parse(fs.readFileSync('amazon.books.json', 'utf-8'));

// Создайте прогресс-бар
const progressBar = new ProgressBar(' [:bar] :percent ', {
  total: data.length,
  width: 50,
  complete: '=',
  incomplete: ' ',
});

// sync моделей с бд
sequelize.sync({ force: true }).then(async () => {
  for (const bookData of data) {
    const book = await Book.create({
      title: bookData.title,
      isbn: bookData.isbn,
      pageCount: bookData.pageCount,
      publishedDate: new Date(bookData.publishedDate?.$date),
      thumbnailUrl: bookData.thumbnailUrl,
      shortDescription: bookData.shortDescription,
      longDescription: bookData.longDescription,
      status: bookData.status,
    });

    for (const authorName of bookData.authors) {
      const [author] = await Author.findOrCreate({
        where: { name: authorName },
      });
      await book.addAuthor(author);
    }

    for (const categoryName of bookData.categories) {
      const [category] = await Category.findOrCreate({
        where: { name: categoryName },
      });
      await book.addCategory(category);
    }

    progressBar.tick(); // Увеличивайте прогресс-бар при каждой итерации
  }

  console.log('Work will be done');
});
