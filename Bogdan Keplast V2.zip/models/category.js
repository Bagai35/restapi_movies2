const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Category = sequelize.define('Category', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
},
  {
  createdAt: false, // отключает поле createdAt
  updatedAt: false
  });

module.exports = Category;
