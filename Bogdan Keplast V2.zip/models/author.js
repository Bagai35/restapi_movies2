const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Подключение к базе данных из вашего файла конфигурации

const Author = sequelize.define('Author', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
},
{
  timestamps: false
});

module.exports = Author;
