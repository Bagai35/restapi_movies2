const sequelize = require('../config/database');
const Book = require('./book');
const Author = require('./author');
const Category = require('./category');

// Определите отношения между моделями
Book.belongsToMany(Author, { through: 'BookAuthor', timestamps: false });
Book.belongsToMany(Category, { through: 'BookCategory', timestamps: false });
Author.belongsToMany(Book, { through: 'BookAuthor', timestamps: false });
Category.belongsToMany(Book, { through: 'BookCategory', timestamps: false });

module.exports = {
  sequelize,
  Book,
  Author,
  Category,
};
